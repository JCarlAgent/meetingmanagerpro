import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://krsbgejnviqyzytxaqaz.supabase.co';
const supabaseKey = 'sb_publishable_dbWs7LMmwjAbBkDXYkJSgg_cN0jfHFq';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };